    // Reading from a file
    std::ifstream inFile(filename);
    if (inFile.is_open()) {
        std::string line;
        while (getline(inFile, line)) {
            std::cout << line << '\n';
        }
        inFile.close(); // Close the file
    } else {
        std::cerr << "Unable to open file for reading\n";
    }

    return 0;
}
/*std::ifstream inFile(filename);: Creates an ifstream object named 
inFile and opens the file specified by filename for reading.
if (inFile.is_open()): Checks if the file was successfully opened.
std::string line;: Declares a string variable line to hold each line read from the file.
while (getline(inFile, line)): Reads lines from the file into line until the end of the file is reached.
std::cout << line << '\n';: Outputs each line read from the file to the console.
inFile.close();: Closes the file after reading is complete.
else: If the file could not be opened, it outputs an error message to std::cerr.*/
