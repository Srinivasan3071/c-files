Containers: The STL provides a range of containers, such as vector, list, map, set, and stack, 
which can be used to store and manipulate data.

Algorithms: The STL provides a range of algorithms, such as sort, find, and binary_search, 
which can be used to manipulate data stored in containers.

Iterators: Iterators are objects that provide a way to traverse the elements of a container. 
The STL provides a range of iterators, 
such as forward_iterator, bidirectional_iterator, and random_access_iterator, 
that can be used with different types of containers.

Function Objects: Function objects, also known as functors, are objects 
that can be used as function arguments to algorithms.
They provide a way to pass a function to an algorithm, 
allowing you to customize its behavior.

Adapters: Adapters are components that modify the behavior of other components in the STL. 
For example, the reverse_iterator adapter can be used to reverse the order of elements in a container.


STL has 4 components:

Algorithms
Containers
Functors
Iterators

1. Algorithms
The header algorithm defines a collection of functions specially designed to be used on a range of elements. They act on containers and provide means for various operations for the contents of the containers.

Algorithm
Sorting
Searching
Important STL Algorithms
Useful Array algorithms

Numeric


2. Containers
Containers or container classes store objects and data.
There are in total seven standards “first-class” container 

classes and three container adaptor classes and only seven header files that provide access to these 
containers or container adaptors.

Sequence Containers: implement data structures that can be accessed in a sequential manner.
vector
list
deque
arrays
forward_list( Introduced in C++11)
 
3.3. Functors
The STL includes classes that overload the function call operator. 
Instances of such classes are called function objects or functors. 
Functors allow the working of the associated function to be customized with the help of parameters to be passed. 
Must Read – Functors

4. Iterators
As the name suggests, iterators are used for working on a sequence of values.
They are the major feature that allows generality in STL. Must Read – Iterators