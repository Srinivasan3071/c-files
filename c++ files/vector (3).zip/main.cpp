#include <iostream> 
#include <vector>
using namespace std;
int main(){
    //vector declaring without element
    vector<int> a;
    for(int i=6;i<=12;i++){
        a.push_back(i);
        cout<<i;
    }
}