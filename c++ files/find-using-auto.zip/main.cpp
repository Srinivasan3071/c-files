#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    // Initialize the vector with values from 65 to 90
    vector<int> a;
    for (int i = 65; i <= 90; ++i) {
        a.push_back(i);
    }

    cout << "Enter search value: ";
    int x;
    cin >> x;

    // Search for the element in the vector
    auto s = find(a.begin(), a.end(), x);

    if (s != a.end()) {
        cout << "Element found: " << *s << endl;
        cout << "Yes" << endl;
    } else {
        cout << "No" << endl;
    }

    return 0;
}
