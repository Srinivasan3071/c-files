// Base class
/*Polymorphism in C++ is a key concept in object-oriented programming (OOP) 
that allows objects of different types to be treated as objects of a common superclass. 
This enables a single interface to be used to represent different types of objects 
and provides a way to implement dynamic behavior in a program.#include <iostream>
using namespace std;*/
//scenario-behaviour..
#include<iostream>
using  namespace std;
class Animal {
  public:
    void show(int i) {
        cout << "Integer: " << i << endl;
    }
};

// Derived class
class Pig : public Animal {
    
  public:
  void show(double d) {
        cout << "Double: " << d << endl;
    }
    
};

// Derived class
class Dog : public Animal {
  public:
  void show(float f) {
        cout << "Double: " << f<< endl;
    }
    
};

int main() {
  Animal myAnimal;
  Pig myPig;
  Dog myDog;

  myAnimal.show();
  myPig.show();
  myDog.show();
  return 0;
}




