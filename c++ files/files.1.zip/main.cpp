#include <iostream>
#include <fstream>
#include <string>
using namespace std;
/*#include <iostream>: Includes the standard input-output stream library, 
allowing the program to use std::cout for console output and std::cerr for error messages.

#include <fstream>: Includes the file stream library, 
which provides the classes needed for file operations (std::ofstream, std::ifstream, and std::fstream).

#include <string>: Includes the string library, allowing the use of std::string.*/
int main() {
    string filename = "example.txt";
/*int main(): The main function where the program execution begins.
std::string filename = "example.txt
Declares a string variable filename and initializes it with the name of the file to be used for reading and writing.*/


    // Writing to a file
    fstream outFile(filename);
    if (outFile.is_open()) {
        outFile << "Hello, World!\n";
        outFile << "This is a test.\n";
        outFile.close(); // Close the file
    } else {
        std::cerr << "Unable to open file for writing\n";
    }
}
/*std::ofstream outFile(filename);: Creates an ofstream object named outFile and 
opens the file specified by filename for writing. If the file does not exist, it will be created.
if (outFile.is_open()): Checks if the file was successfully opened.
outFile << "Hello, World!\n";: Writes the string "Hello, World!" followed by a newline character to the file.
outFile << "This is a test.\n";: Writes the string "This is a test." followed by a newline character to the file.
outFile.close();: Closes the file to ensure all data is written and resources are freed.
else: If the file could not be opened, it outputs an error message to std::cerr.*/
