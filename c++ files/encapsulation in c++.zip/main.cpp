/*Encapsulation is one of the fundamental principles of object-oriented programming (OOP). 
It refers to the bundling of data (attributes) and methods (functions) that operate on the data into a single unit called a class. 
Encapsulation restricts direct access to some of the object's components, which is a 
means of preventing unintended interference and misuse of the data. Instead, access to the data is provided through public methods.

Key Concepts of Encapsulation
1.Data Hiding: Only essential details are exposed, while implementation details are hidden.

2.Access Specifiers: Control the access level of the class members. 
Typically, data members are kept private and accessed via public member functions.
Benefits of Encapsulation
1.Modularity: The source code for an object can be written and maintained independently of the source code for other objects.

2.Data Protection: Encapsulation allows the internal state of an object to be protected from unintended or harmful modifications.
Ease of Maintenance: Changes to the encapsulated code can be made with minimal impact on the rest of the program.
Enhanced Security: Sensitive data can be kept private and exposed only through controlled interfaces.*/

#include<iostream>
using namespace std;
class Emplyoee{
    private:
    int salary;
    public:
    void setsalary(int s){
        salary=s;
    }
    int getsalary(){
        return salary;
    }
};
int main(){
    Emplyoee myobj;
    myobj.setsalary(20000);
    cout<<myobj.getsalary();
}
