/*To illustrate how the Fibonacci series is constructed, let’s calculate the first few terms manually:

- \( F(0) = 0 \)
- \( F(1) = 1 \)
- \( F(2) = F(1) + F(0) = 1 + 0 = 1 \)
- \( F(3) = F(2) + F(1) = 1 + 1 = 2 \)
- \( F(4) = F(3) + F(2) = 2 + 1 = 3 \)
- \( F(5) = F(4) + F(3) = 3 + 2 = 5 \)
- \( F(6) = F(5) + F(4) = 5 + 3 = 8 \)
- \( F(7) = F(6) + F(5) = 8 + 5 = 13 \)
*/
#include <iostream>

// Function to calculate Fibonacci number using recursion
int fibonacci(int n) {
    if (n <= 1) { // Base cases: fibonacci(0) is 0, fibonacci(1) is 1
        return n;
    } else {
        return fibonacci(n - 1) + fibonacci(n - 2); // Recursive case
    }
}

int main() {
    int number;

    std::cout << "Enter a positive integer: ";
    std::cin >> number;

    if (number < 0) {
        std::cout << "Fibonacci is not defined for negative numbers." << std::endl;
    } else {
        int result = fibonacci(number);
        std::cout << "Fibonacci number " << number << " is " << result << std::endl;
    }

    return 0;
}

