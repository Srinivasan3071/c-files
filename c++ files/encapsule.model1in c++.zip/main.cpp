#include <iostream>
using namespace std;

class Person {
private:
    string name;
    int age;

public:
    // Setter for name
    void setName(string n) {
        name = n;
    }

    // Getter for name
    string getName() {
        return name;
    }

    // Setter for age
    void setAge(int a) {
        if (a > 0) {
            age = a;
        } else {
            cout << "Age must be positive." << endl;
        }
    }

    // Getter for age
    int getAge() {
        return age;
    }

    // Function to display person's details
    void displayInfo() {
        cout << "Name: " << name << ", Age: " << age << endl;
    }
};

int main() {
    Person person;
    person.setName("John Doe");
    person.setAge(30);
    person.displayInfo();

    return 0;
}

