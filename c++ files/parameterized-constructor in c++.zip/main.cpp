//parameterized constructor
#include <iostream>
using namespace std;

class Example {
public:
    int value;

    // Parameterized constructor
    Example(int v) {
        value = v;
        cout << "Parameterized constructor called" << std::endl;
    }

    void display() {
        cout << "Value: " << value << std::endl;
    }
};

int main() {
    Example obj(10); // Parameterized constructor is called with value 10
    obj.display();

    return 0;
}
