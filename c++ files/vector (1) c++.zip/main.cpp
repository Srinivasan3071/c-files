#include<iostream>
using namespace std;
#include <vector>
int main(){
    vector<int>a;
    for(int i=1;i<=5;i++){
        a.push_back(i);
        cout<<i<<endl;
    }
    int sum=0;
    for (auto i = a.begin(); i != a.end(); ++i) {
    sum=sum+*i;
    }
        cout << sum << " ";
       
}
