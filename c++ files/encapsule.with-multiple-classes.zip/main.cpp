#include <iostream>
#include <string>
using namespace std;

class Address {
private:
    string street;
    string city;
    int zipCode;

public:
    // Setters
    void setStreet(const string &s) {
        street = s;
    }

    void setCity(const string &c) {
        city = c;
    }

    void setZipCode(int z) {
        zipCode = z;
    }

    // Getters
    string getStreet() const {
        return street;
    }

     string getCity() const {
        return city;
    }

    int getZipCode() const {
        return zipCode;
    }

    // Display address
    void displayAddress() const {
        cout << "Street: " << street << ", City: " << city << ", Zip Code: " << zipCode << endl;
    }
};

class Person {
private:
    string name;
    int age;
    Address address; // Composition - Person "has a" Address

public:
    // Setters
    void setName(const std::string &n) {
        name = n;
    }

    void setAge(int a) {
        if (a > 0) {
            age = a;
        } else {
            cout << "Age must be positive." << endl;
        }
    }

    void setAddress(const Address &addr) {
        address = addr;
    }

    // Getters
    string getName() const {
        return name;
    }

    int getAge() const {
        return age;
    }

    Address getAddress() const {
        return address;
    }

    // Display person's details
    void displayInfo() const {
        cout << "Name: " << name << ", Age: " << age << endl;
        address.displayAddress();
    }
};

int main() {
    Person person;
    Address addr;
    
    addr.setStreet("123 Main St");
    addr.setCity("Anytown");
    addr.setZipCode(12345);

    person.setName("John Doe");
    person.setAge(30);
    person.setAddress(addr);
    
    person.displayInfo();

    return 0;
}
