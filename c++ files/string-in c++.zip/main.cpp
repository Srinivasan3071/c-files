//string-->is not a data type,it is a predefined  class in c++.
#include<iostream>
#include<string>
using namespace std;
int main(){
    string s1="hi";/*-->it a object created in class called string;*/
    string s2("hello");
    cout<<s2<<endl;
    string s3=s1;/*-->it is easier to copy string in c++*/
    string s4(s2);
    string s5(2,'h');
    cout<<s5;
    
    
    
}
#include<iostream>
#include<string>
#include <limits>
using namespace std;

int main() {
    string s1 = "hi";
    string s2("hello");
    string s3(s2);
    string s4 = s1;
    string s5(6, 'h');
    string s6;

    // Read a single word from standard input
    cin >> s6;
    cout << s6 << endl;

    // Clear the newline character left in the input buffer
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    // Read a full line from standard input
    string s7;
    getline(cin, s7);
    cout << s7 << endl;

    // Append s2 to s1
    string s8 = s1.append(s2);
    cout << s8.length() << endl;
    string s9="hello";
    s9[0]='a';
    cout<<s9;
    

    return 0;
}


