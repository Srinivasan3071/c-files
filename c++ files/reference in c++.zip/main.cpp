
/*In C++, a reference is an alias for another variable. Once a reference is initialized to a variable,
it cannot be changed to refer to another variable. References are useful for function parameter passing, 
returning values from functions, and providing an alternative to pointers for variable access.

Key Characteristics of References

1.Alias for a Variable: A reference acts as an alternative name for an existing variable.

2.Initialization: A reference must be initialized when it is declared.

3.Cannot be Null: Unlike pointers, references cannot be null and must always reference a valid object.
No Reassignment: Once initialized, a reference cannot be made to refer to a different object or variable.*/


#include <iostream>
using namespace std;

int main() {
    int var = 42;       // Declare an integer variable
    int& ref = var;     // Declare a reference to var

    // Output the value of var
    cout << "Value of var: " << var << endl;
    
    // Output the value of ref (which is the value of var)
    cout << "Value of ref: " << ref << endl;

    // Modify the value through the reference
    ref = 100;
    
    // Output the value of var after modification
    cout << "Value of var after modification: " << var << endl;

    // Output the value of ref after modification
    cout << "Value of ref after modification: " << ref << endl;

    return 0;
}

