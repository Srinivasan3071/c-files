
#include <iostream>
using namespace std;

int main()
{
  int a,b;
  cout<<"enteer the number";
  cin>>a>>b;
  try{
      if(b==0)
      throw "divide by zero";
      cout<<a/b;
  }
  catch(const char *ch)
  {
      cout<<"error"<<ch;
  }
  
  cout<<"end of program";

    return 0;
}