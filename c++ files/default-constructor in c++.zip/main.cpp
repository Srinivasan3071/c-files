
#include <iostream>
using namespace std;

class Example {
public:
    int value;

    // Default constructor
    Example() {
        value = 0;  // Initialize value to 0
        cout << "Default constructor called" << std::endl;
    }

    void display() {
       cout << "Value: " << value << std::endl;
    }
};

int main() {
    Example obj; // Default constructor is called
    obj.display();

    return 0;
}



