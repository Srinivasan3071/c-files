/* files is a permanent storage in the computer,-->harddisk,
if we want to store the generated output,-->then we write in the file,
so we open a file and write our program into the file,
students data-->we want to sort the name in alphabetical order and write into new program.
how to open the file,read,write,access.
 thats why we usebfstream.
 #include<iostream>
 */
 /*#include <iostream>
 #include<fstream>
 using namespace std;
 int main(){
     fstream file;
     file.open("my file",ios::out);
     //cout<<"hi";
     file<<"i am writing this to the file";/*stored in the buffer*/
 /*    file.close();
     
     file.open("my file",ios::in);
     string s;
     while(file>>s)
     {
     cout<<s<<' ';
 }}*/
 

