/*
The diamond problem in inheritance is a well-known issue in object-oriented programming 
languages that support multiple inheritance, such as C++. It occurs when a class inherits 
from two classes that both derive from a common base class. This situation creates an ambiguity in the inheritance hierarchy,
leading to potential problems such as duplicated base class instances and ambiguity in method calls.#include <iostream>*/
#include<iostream>
using namespace std;
class A {
public:
    void show() {
        cout << "Class A" << std::endl;
    }
};

class B : public A { };
class C : public A { };

// Diamond problem
class D : public B, public C { };

int main() {
    D d;
    // d.show(); // Error: request for member 'show' is ambiguous

    // To resolve ambiguity, we must specify which base class's show() to use:
    d.B::show(); // Output: Class A
    d.C::show(); // Output: Class A

    return 0;
}

