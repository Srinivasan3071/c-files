#include <iostream> 
#include <vector>
using namespace std;
int main(){
    //vector seach
    vector<int> a;
    int b=10;
    for(int i=6;i<=12;i++){
        a.push_back(i);
        
    }
    cout<<"eneter search elemet:";
    int x;
    cin>>x;
    int f=0;
    for(int i:a){
      if(i==x){
    f++;
      }
    }
    if(f>0){
        cout<<"yes";
    }
    else{
        cout<<"no";
    }
}