/*In C++, a constructor is a special member function of a class that is automatically called when an 
object of that class is created. Constructors are used to initialize objects. 
They can be overloaded, which means you can have multiple constructors in the same class, each with different parameters.*/
#include <iostream>
using namespace std;

class MyClass {     // The class
  public:           // Access specifier
    MyClass() {     // Constructor
      cout << "Hello World!";
    }
};

int main() {
  MyClass myObj;    // Create an object of MyClass (this will call the constructor)
  return 0;
}
