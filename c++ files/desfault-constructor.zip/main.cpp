#include <iostream>
using namespace std;

class Person {
public:
    string name;
    int age;

    // Default Constructor
    Person() {
        name = "Unknown";
        age = 0;
    }
};

int main() {
    Person person1;
    cout << person1.name << endl;  // Output: Unknown
    cout << person1.age << endl;   // Output: 0
    return 0;
}
