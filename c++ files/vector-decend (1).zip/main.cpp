#include <iostream> 
#include <vector>
#include<algorithm>
using namespace std;
int main(){
    //vector sort decend using algorith.h
    vector<int> a({10,3,4,1,7,3,9,4});
    
    sort(a.begin(),a.end(),greater<int>());
    for(int i:a){
        cout<<i<<" ";
    }
  
}