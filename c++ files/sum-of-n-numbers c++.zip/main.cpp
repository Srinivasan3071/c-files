#include <iostream> 
#include <vector>
using namespace std;
int main(){
    //sum n numbers
    vector<int> a;
    int b=10;
    for(int i=6;i<=12;i++){
        a.push_back(i);
        
    }
       int sum=0;
    for(int i:a){
        sum=sum+i;
    }
     cout<<sum;
}