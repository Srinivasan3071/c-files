#include <iostream> 
#include <vector>
using namespace std;
int main(){
    //print alphabest in vectors
    vector<int> a;
    for(int i=65;i<=90;i++){
        a.push_back(i);
        
    }
       int sum=0;
       char ch;
    for(int i:a){
        ch=i;
        cout<<ch<<" ";
    }
    
}