#include <iostream> 
#include <vector>
using namespace std;
int main(){
    //vector declaring without element
    vector<int> a;
    int b=10;
    for(int i=6;i<=12;i++){
        a.push_back(i);
        
    }
       a.pop_back();   a.pop_back();   a.pop_back();
    for(int i:a){
        cout<<i<<" ";
    }
}