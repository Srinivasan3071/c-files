#include <iostream>
using namespace std;

class Fraction {
private:
    int numerator;
    int denominator;

public:
    Fraction(int num = 0, int den = 1) : numerator(num), denominator(den) {}//member func
    /*Defines a class named Fraction with two private member variables numerator and denominator.
Provides a constructor Fraction(int num = 0, int den = 1) which 
initializes numerator and denominator with the provided values (or default values of 0 and 1).
Overloads the + operator to add two fractions.
Defines a member function display() to print the fraction.*/

    // Overloading the + operator to add two fractions
    //const Fraction& specifies that the parameter other 
    //is a constant reference to a Fraction object. 
    //Using a reference here is efficient because 
   // it avoids unnecessary copying of objects 
   //when passing them to functions.}
   /*Provides a constructor Fraction(int num = 0, int den = 1) which 
initializes numerator and denominator with the provided values (or default values of 0 and 1).
Overloads the + operator to add two fractions.*/
 
 /*he + operator is overloaded for the Fraction class. This allows us to use the + operator to add two Fraction objects together.
Inside the overloaded + operator function, it calculates the sum of two fractions by following the rules of 
fraction addition: (a/b) + (c/d) = (ad + bc) / bd.
It returns a new Fraction object containing the result of the addition.
*/


 Fraction operator+(const Fraction& other) {
        Fraction result;
        result.numerator = this->numerator * other.denominator + other.numerator * this->denominator;
        result.denominator = this->denominator * other.denominator;
        return result;
    }

    void display() {
      cout << numerator << "/" << denominator;
    }
};
/*Defines a class named Fraction with two private member variables numerator and denominator.
Provides a constructor Fraction(int num = 0, int den = 1) which 
initializes numerator and denominator with the provided values (or default values of 0 and 1).
Overloads the + operator to add two fractions.
Defines a member function display() to print the fraction.*/

int main() {
    Fraction f1(1, 2); // Represents 1/2
    Fraction f2(3, 4); // Represents 3/4

    Fraction f3 = f1 + f2; // Adds f1 and f2

    cout << "Result of addition: ";
    f3.display(); // Output: 5/4

    return 0;
}
/*Defines a class named Fraction with two private member variables numerator and denominator.
Provides a constructor Fraction(int num = 0, int den = 1) which initializes numerator and denominator with the provided values (or default values of 0 and 1).
Overloads the + operator to add two fractions.
Defines a member function display() to print the fraction.*/





